// ----------------------------------------------------------------------------------------------------
// Configuration settings for an xMatters Relevance Engine Integration
// ----------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------
// Name of the filter from conf/deduplicator-filter.xml to be used to detect duplicate events
//----------------------------------------------------------------------------------------------------
var DEDUPLICATION_FILTER_NAME = "";

//----------------------------------------------------------------------------------------------------
// Web Service credentials
//
// Credentials for accessing the XM_CTM_xxx Web service will be stored in 
// a separate password file created using iapassword.bat
//----------------------------------------------------------------------------------------------------
var REMEDY_WS_USERNAME = "xmatters";
var REMEDY_WS_PASSWORD_FILE = "conf/xm_hpd_ws.pwd";

var PROTOCOL = "http";
var MID_TIER_HOSTNAME = "localhost";
var MID_TIER_PORT = "80";
var REMEDY_SERVER_NAME = "remedysd";

var XM_HPD_HELPDESK_WS_URL = PROTOCOL + "://" + MID_TIER_HOSTNAME + ":" + MID_TIER_PORT + "/arsys/services/ARService?server=" + REMEDY_SERVER_NAME + "&webService=XM_HPD_HelpDesk_WS";
var XM_HPD_INCIDENT_WS_URL = PROTOCOL + "://" + MID_TIER_HOSTNAME + ":" + MID_TIER_PORT + "/arsys/services/ARService?server=" + REMEDY_SERVER_NAME + "&webService=XM_HPD_IncidentInterface_WS";
var XM_SUPPORTGROUPASSOC_WS_URL = PROTOCOL + "://" + MID_TIER_HOSTNAME + ":" + MID_TIER_PORT + "/arsys/services/ARService?server=" + REMEDY_SERVER_NAME + "&webService=XM_SupportGrp_SupportGrpAssoci_WS";

// The "Host" header value which will be sent for the HTTP WS POST to the Remedy Midtier Server
var HOST_HEADER = MID_TIER_HOSTNAME;

// =====================================================================================================================
// Global variables
// =====================================================================================================================

var notePrefix = "[xMatters] - ";
var log = new Logger("BMC Remedy Incident Worklog Update: ");

// Incident Properties
GENERIC_TICKET_ID = 'Incident Number';

GENERIC_MESSAGE = 'Incident Message Detail';
