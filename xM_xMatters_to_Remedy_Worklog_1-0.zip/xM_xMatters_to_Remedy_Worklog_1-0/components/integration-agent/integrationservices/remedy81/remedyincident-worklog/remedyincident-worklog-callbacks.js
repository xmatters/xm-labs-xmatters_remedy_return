/*
  Called when response object has been received from the form
*/
function apia_callback(msg) {
  
  var str = "Received message from xMatters:";
  str += "\nIncident: " + msg.incident_id;
  str += "\nEvent ID: " + msg.eventidentifier;
  str += "\nCallback type: " + msg.xmatters_callback_type;
  IALOG.debug(str);
  
  try {
  
    switch (msg.xmatters_callback_type) {

      case "response":
        handleResponse(msg);
        break;
        
      case "status":
        handleEventStatus(msg);
        break;
      
      case "deliveryStatus":
        handleDeliveryStatus(msg);
        break;
    }
    
  } catch (e) {
    log.error("apia_callback(" + msg.eventidentifier + ", " + msg.xmatters_callback_type + "): caught Exception - name: [" + e.name + "], message [" + e.message + "]: " + msg);

    throw e;
  }
}

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * handleEventStatus
 *
 * The main routine for handling event status messages from xMatters
 *
 * ---------------------------------------------------------------------------------------------------------------------
 */
function handleEventStatus(msg)
{

	var incidentId = getIncidentID( msg );
	var message = getMessage( msg );
	var userAnnotation = "null".equals(message) ? "" : message;

	switch (msg.status) {
  
	case "active":     // event created 
		addAnnotationToIncidentWorkInfo( incidentId, userAnnotation );		
		break;
      
	case "terminated": // time expired 
		// log only, do annotate
		log.info("handleEventStatus [terminated] ignored for - Event ID " + msg.eventidentifier + ", incidentId [" + incidentId + "], annotation [" + userAnnotation + "]");
		break;
      
    case "terminated_external": // terminated by user
		// log only, do annotate
		log.info("handleEventStatus [terminated external] ignored for - Event ID " + msg.eventidentifier + ", incidentId [" + incidentId + "], annotation [" + userAnnotation + "]");
		break;      
	}
}

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * handleDeliveryStatus
 *
 * The main routine for handling delivery status messages from xMatters
 *
 * If an message is delivered successfully, a comment is added to the worklog of the Remedy Incident ticket quoting the user and device that was targeted
 * If an message delivery fails, a comment is added to the worklog of the Remedy Incident ticket quoting the user and device that was targeted
 * ---------------------------------------------------------------------------------------------------------------------
 */
function handleDeliveryStatus(msg)
{
	log.debug("Enter - handleDeliveryStatus");

	if ( msg.deliverystatus ) 
	{
	
		var incidentId = getIncidentID( msg );
		var message = getMessage( msg );
		var userAnnotation = "null".equals(message) ? "" : message;

		switch (String(msg.deliverystatus).toLowerCase()) 
		{
			case "delivered":
				// log only, do annotate
				log.info("handleDeliveryStatus [delivered] ignored for - Event ID " + msg.eventidentifier + ", incidentId [" + incidentId + "], annotation [" + userAnnotation + "]");
				break;
        
			case "failed": 
				// log only, do annotate
				log.info("handleDeliveryStatus [failed] ignored for - Event ID " + msg.eventidentifier + ", incidentId [" + incidentId + "], annotation [" + userAnnotation + "]");
				break;
		}
	}
	
	log.debug("Exit - handleDeliveryStatus");
}

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * handleResponse
 *
 * The main routine for handling user responses
 *
 * ---------------------------------------------------------------------------------------------------------------------
 */
function handleResponse(msg)
{
	log.debug("Enter - handleResponse");
	log.debug("handleResponse - Event ID " + msg.eventidentifier + ", response [" + msg.response + "], responder [" + responder + "], device [" + device + "]");

	var incidentId = getIncidentID( msg );
	var message = getMessage( msg );
	var userAnnotation = "null".equals(message) ? "" : message;

    // log only, do annotate
	log.info("handleResponse [" + msg.response + "] ignored for - Event ID " + msg.eventidentifier + ", incidentId [" + incidentId + "], annotation [" + userAnnotation + "]");
  
	log.debug("Exit - handleResponse");
}

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * addAnnotationToIncidentWorkInfo
 *
 * Add an annotation as a result of the event injection processing. Catch any exceptions thrown.
 *
 * @param incidentId
 * @param notes
 * ---------------------------------------------------------------------------------------------------------------------
 */
function addAnnotationToIncidentWorkInfo( incidentId, notes )
{
    log.debug("Enter - addAnnotationToIncidentWorkInfo");
    log.info("addAnnotationToIncidentWorkInfo - incidentId [" + incidentId + "], note [" + notes + "]");

    try
    {
      var incidentService = new XMHPDIncidentInterfaceWS(new WSUtil(), XM_HPD_INCIDENT_WS_URL);
      
      var incident = newRemedyObject();
      incident.Incident_Number = formatIncidentID(incidentId);
      
      Incident.setWorkLog(incident, notes);
      incidentService.addWorkLog(REMEDY_WS_USERNAME, REMEDY_WS_PASSWORD, incident);
      
    } catch (e)
    {
        log.error("Failed to annotate incident: Exception - name [" + e.name + "], message [" + e.message + "]");
        log.error("Incident ID [" + incidentId + "]");
    }

    log.debug("Exit - addAnnotationToIncidentWorkInfo");
}

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * getIncidentID
 *
 * Check whether additionalTokens and Incident_Number are present, and return the content if they are. 
 * If not, an exception is thrown.
 *
 * @param msg
 * ---------------------------------------------------------------------------------------------------------------------
 */
function getIncidentID( msg ) {
  
  if ('additionalTokens' in msg) {
    
	if (GENERIC_TICKET_ID in msg.additionalTokens)
	{
		return msg.additionalTokens[GENERIC_TICKET_ID];
	}  
	
  }
  
  throw { name: "DataException", message: "Property that identifies the incident is not found in event callback data of type " + msg.xmatters_callback_type + " for event ID " + msg.eventidentifier 
    + ".Make sure 'Include in Callbacks' is set in the form's layout for a property configured as GENERIC_TICKET_ID in configuration.js"};  
}

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * getMessage
 *
 * Check whether additionalTokens and Worklog Message are present, and return the content if they are. 
 *
 * @param msg
 * ---------------------------------------------------------------------------------------------------------------------
 */
function getMessage( msg ) {
  
  if ('additionalTokens' in msg) {
    
 	if (GENERIC_MESSAGE in msg.additionalTokens)
	{
		return msg.additionalTokens[GENERIC_MESSAGE];
	}  
	else
	{
		return null;
	}
  }
}

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * formatIncidentID
 *
 * Check whether the supplied ticket id matches the Remedy Incident ID format template "INC001000000001. 
 * Cleanup approach:
 * 1. Strip all non-numeric characters
 * 2. Check the length of the remainder (should be 12)
 *    - If length > 12 throw error and stop
 *    - If length = 12 AND first 3 characters = 001 then all good, else throw error and stop
 *    - If length < 12 and >9, prefix with 0s until length = 12,check first 3 characters, if 001 then all good, else 
 *      throw error and stop 
 *    - If length <=9, prefix with 0s until length = 9, then prefix with 001
 * 3. If no error then Prefix with INC and return
 * @param id
 * ---------------------------------------------------------------------------------------------------------------------
 */
function formatIncidentID( id ) 
{
	log.debug("Enter - formatIncidentID");

	var error = false;
	var str = "";
	var errId = id;
	
	if (!(typeof id === 'string' || id instanceof String))
	{
		error = true;
		errId = "";
	}
	else
	{
		log.debug("Incident ID (preformat): " + id);
		str = String(id);
		// Strip all non-numeric characters from string
		str = str.replace(/\D/g, '');
		log.debug("Incident ID (non-numeric stripped): " + str);
		
		if (str.length > 12 || str.length < 1)
		{
			error = true;
		}
		else if (str.length == 12)
		{
			if (str.substring(0,3) != "001")
			{
				error = true;
			}
		}
		else if (str.length < 12 && str.length >= 1)
		{
			str = prefixID(str);
			if (str.substring(0,3) != "001")
			{
				error = true;
			}			
		}
	}
  
	if (error)
	{
		throw { name: "DataException", message: "Property that identifies the incident [" + errId  + "] is not in the correct format.  Make sure incident id has a valid format"};  
	}
	else
	{
		log.debug("Exit - formatIncidentID");
		return "INC" + str;
	}
}

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * prefixID
 *
 * Takes the passed in string, prefixes as needed to ensure length is 12, first 3 characters are 001 and remainder of 
 * prefix completed with 0s
 *
 * @param str
 * ---------------------------------------------------------------------------------------------------------------------
 */
function prefixID(str)
{
	log.debug("Rnter - prefixID");
	log.debug("str prefixID [preformat]: " + str);
	var len;
	
	len = str.length;
	if (len <= 9)
	{
		while (len < 9)
		{
			str = "0" + str;
			len++;
		}
		str = "001" + str;
	}
	else if (len >= 10)
	{
		while (len < 12)
		{
			str = "0" + str ;
			len++;
		}
	}
	log.debug("str prefixID [postformat]: " + str);
	log.debug("Exit - prefixID");
	return str;
}
