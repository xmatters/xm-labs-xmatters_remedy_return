/*
  Called when object is being injected by APClient.Bin or via HTTP
*/
function apia_event(formObject) {
	return formObject;	
}

