importPackage(java.util);
importPackage(java.io);
importPackage(java.text);

importClass(Packages.com.alarmpoint.integrationagent.apxml.APXMLMessage);
importClass(Packages.com.alarmpoint.integrationagent.apxml.APXMLMessageImpl);
importClass(Packages.com.alarmpoint.integrationagent.apxml.APXMLToken);
importClass(Packages.com.alarmpoint.integrationagent.soap.exception.SOAPRequestException);

importClass(Packages.com.thoughtworks.xstream.XStream);
importClass(Packages.com.thoughtworks.xstream.converters.reflection.PureJavaReflectionProvider);

importClass(Packages.org.apache.commons.httpclient.Header);
importClass(Packages.org.apache.commons.httpclient.HttpVersion);
importClass(Packages.org.mule.providers.http.HttpResponse);

var PRODUCT_VERSION_NUMBER = "81";

// Core Javascript files provided by the IA
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/lib/javascript/core/baseclass.js");
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/lib/javascript/core/logger.js");
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/lib/javascript/core/util.js");
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/lib/javascript/webservices/wsutil.js"); 
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/lib/javascript/webservices/soapfault.js");
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/lib/javascript/xmatters/xmattersws.js"); 

// REB support
load("lib/integrationservices/javascript/event.js");
// xM REST API
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/remedyincident-worklog/xmrestapi.js");

// Integration-specific Javascript files
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/util.js");
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/remedyincident-worklog/configuration.js");
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/remedyincident-worklog/xm-hpd-incident-interface-ws.js");
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/remedyincident-worklog/updateIncident.js");
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/remedyincident-worklog/http_event.js");

load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/remedyincident-worklog/remedyincident-worklog-event.js");
load("integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/remedyincident-worklog/remedyincident-worklog-callbacks.js");
