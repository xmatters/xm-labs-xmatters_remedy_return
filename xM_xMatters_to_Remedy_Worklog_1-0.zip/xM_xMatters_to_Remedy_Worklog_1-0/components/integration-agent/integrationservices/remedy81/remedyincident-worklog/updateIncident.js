var INCIDENT_ACTION_MODIFY = "MODIFY";

var WORK_INFO_TYPE = "Customer Communication";
var WORK_INFO_VIEW_ACCESS = "Public";
var WORK_INFO_LOCKED = "Yes";
var WORK_INFO_SUMMARY = "xMatters";
var WORK_INFO_SUMMARY_FIELD_LENGTH = 100;
var WORK_INFO_SOURCE = "Other";
var SUMMARY_PREFIX = "[xMatters Broadcast] - ";

Incident = {};

(function(){

  /**
   * ---------------------------------------------------------------------------------------------------------------------
   * setIncidentWorkLog
   *
   * set the fields in the incident associated with the annotations from the user and xMatters, dependant on the value
   * of addResponseAnnotations
   *
   * ---------------------------------------------------------------------------------------------------------------------
   */
 	Incident.setWorkLog = function(incident, notes) {
    log.debug("Enter - setIncidentWorkLog");
    log.info("setIncidentWorkLog - incident number [" + incident.Incident_Number + "] notes [" + notes + "]");

	incident.Action = INCIDENT_ACTION_MODIFY;
	incident.Work_Info_Type = WORK_INFO_TYPE;
	incident.Work_Info_Locked = WORK_INFO_LOCKED;
	incident.Work_Info_View_Access = WORK_INFO_VIEW_ACCESS;
	incident.Work_Info_Summary = WORK_INFO_SUMMARY;
	incident.Work_Info_Source = WORK_INFO_SOURCE;
	incident.Work_Info_Notes = SUMMARY_PREFIX + notes + "."

    log.debug("Exit - setIncidentWorkLog");
}

})();