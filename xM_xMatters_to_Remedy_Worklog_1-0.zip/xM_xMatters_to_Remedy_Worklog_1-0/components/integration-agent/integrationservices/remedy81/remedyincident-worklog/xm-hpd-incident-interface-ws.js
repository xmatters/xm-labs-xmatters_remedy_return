/******************************************************************************/
/*            Start of Remedy XM_HPD_IncidentInterface WS Definition          */
/******************************************************************************/
var XMHPDIncidentInterfaceWS = BaseClass.extend({

  LOG_SOURCE: "xm-hpd-incident-interface-ws.js: ",
  XM_HPD_INCIDENT_INTERFACE_WSDL_DEFN: "integrationservices/remedy" + PRODUCT_VERSION_NUMBER + "/remedyincident-worklog/soap/XM-HPD-IncidentInterface-WS-soapui-project.xml",
  XM_HPD_INCIDENT_INTERFACE_SOAP_VERSION: "1_1",
  
  /**
   * Initialize the class variables
   * @param wsutil instance of the WSUtil class for making the webservice calls
   * @param endpoint URL of the webservice endpoint
   */
  init: function(wsutil, endpoint)
  {
    this.log = new Logger(this.LOG_SOURCE);
    this.wsutil = wsutil;
    this.endpoint = endpoint;
	this.headers = new HashMap();
	this.headers.put("Host", HOST_HEADER);
  },
  
  /**
   * Add a worklog entry to the incident in Remedy
   * @param username name of the user making the request
   * @param password string repesenting the user password
   * @param incident instance of the incident to update
   */
  addWorkLog: function(username, password, incident)
  {
    this.log.debug("Enter - addWorkLog");

    var msg = new SOAPMessage(this.XM_HPD_INCIDENT_INTERFACE_WSDL_DEFN, "AddWorkLog", "AddWorkLog", this.XM_HPD_INCIDENT_INTERFACE_SOAP_VERSION);
    msg.setParameter("userName", username);
    msg.setParameter("password", password);
    msg.setParameter("Action", incident.Action);
    msg.setParameter("Work_Info_Summary", getNonNullValue(incident.Work_Info_Summary).substring(0,WORK_INFO_SUMMARY_FIELD_LENGTH - 1));
    msg.setParameter("Work_Info_Notes", getNonNullValue(incident.Work_Info_Notes));
    msg.setParameter("Work_Info_Type", getNonNullValue(incident.Work_Info_Type));
    msg.setParameter("Work_Info_Source", getNonNullValue(incident.Work_Info_Source));
    msg.setParameter("Work_Info_Locked", getNonNullValue(incident.Work_Info_Locked));
    msg.setParameter("Work_Info_View_Access", getNonNullValue(incident.Work_Info_View_Access));
    msg.setParameter("Incident_Number", incident.Incident_Number);
    
    // Update the incident assignee in Remedy
    this.wsutil.sendReceive(this.endpoint, msg, this.headers);
    this.log.debug("Exit - addWorkLog");
  }
  
});
