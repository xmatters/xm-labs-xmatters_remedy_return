XMRESTAPI = {};

(function(){

  // Utility methods  
  XMRESTAPI.checkResponse = function(response, ignoreError) {
  
    if ( response.status !== undefined && response.status != XMRESTAPI.RESPONSE_SUCCESS) {
      // Ignore status?
      if (ignoreError && ignoreError['status'] != null && ignoreError['status'] == response.status) {
        IALOG.debug("XM REST API: checkResponse status " + response.status + " will be treated as success");
        return response;
      }
      var error; 
      try {
        var body = JSON.parse(response.body);
        
        if (ignoreError && ignoreError['type'] != null && ignoreError['type'] == body.type) {
          IALOG.debug("XM REST API: checkResponse error type " + response.status + " will be treated as success");
          return response;
        }
        error = body.message;
      } catch (e) {
        error = "xMatters server returned status " + response.status;
      }     
      throw error;
    }
    
    return response;
  };

  // public functions  
  XMRESTAPI.getUserDetails = function( targetName ) {
	if (targetName != "")
    {
		IALOG.debug("XM REST API: getUserDetails for " + targetName);
		var url = WEB_SERVICE_URL.substring(0, WEB_SERVICE_URL.indexOf("api") - 2) + "api/xm/1/people/" + targetName;
		var response = XMIO.get(url, INITIATOR, INITIATOR_PASSWORD);
		IALOG.debug("XM REST API: getUserDetails received " + response.status + " " + response.body);
		XMRESTAPI.checkResponse( response );
		return JSON.parse(response.body);
	}
	else
	{
		IALOG.error("XM REST API: getUserDetails for " + targetName + " FAILED as targetName is UNDEFINED");
		return null;
	}
  };
  
})();